var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/stripewebhook.js
var stripewebhook_exports = {};
__export(stripewebhook_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(stripewebhook_exports);
var import_stripe = __toESM(require("stripe"));
var import_supabase_js = require("@supabase/supabase-js");
var config = { rawBody: true };
var stripe = new import_stripe.default(process.env.STRIPE_SECRET_KEY);
var supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
var ACTIVE_STATUSES = /* @__PURE__ */ new Set(["active", "trialing", "past_due"]);
function planFromPriceId(id) {
  if (!id) return null;
  if (id === process.env.STRIPE_PRICE_ID_MONTHLY) return "monthly";
  if (id === process.env.STRIPE_PRICE_ID_YEARLY) return "yearly";
  return null;
}
async function upsertProfile({ email, customerId, planCode, isSubscribed }) {
  if (!email) return;
  email = email.toLowerCase();
  const { data: existing } = await supabase.from("profiles").select("id, email, is_subscribed, plan, customer_id").eq("email", email).maybeSingle();
  const updatePayload = {
    email,
    customer_id: customerId ?? existing?.customer_id ?? null,
    plan: isSubscribed ? planCode : existing?.plan ?? null,
    is_subscribed: isSubscribed || existing?.is_subscribed || false
  };
  if (existing?.id) updatePayload.id = existing.id;
  const { error } = await supabase.from("profiles").upsert(updatePayload, { onConflict: "email" });
  if (error) console.error("\u274C Supabase upsert failed:", error);
  else
    console.log(
      `\u2705 Upserted ${email} | subscribed=${updatePayload.is_subscribed} | plan=${updatePayload.plan}`
    );
}
async function handler(event) {
  console.log("\u{1F4E9} Stripe webhook received");
  if (!event.body) {
    console.error("\u274C No webhook body");
    return { statusCode: 400, body: "Webhook Error: No webhook payload was provided." };
  }
  const sig = event.headers["stripe-signature"];
  if (!sig) {
    console.error("\u274C Missing Stripe signature");
    return { statusCode: 400, body: "Webhook Error: Missing Stripe signature" };
  }
  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error("\u274C Signature verification failed:", err.message);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }
  console.log(`\u2705 Verified event: ${stripeEvent.type}`);
  try {
    switch (stripeEvent.type) {
      case "checkout.session.completed": {
        const session = stripeEvent.data.object;
        const email = session.customer_details?.email || session.customer_email || null;
        const customerId = session.customer;
        let planCode = null;
        let isSubscribed = false;
        if (session.subscription) {
          const sub = await stripe.subscriptions.retrieve(session.subscription);
          const priceId = sub.items?.data?.[0]?.price?.id || null;
          planCode = planFromPriceId(priceId);
          isSubscribed = ACTIVE_STATUSES.has(sub.status);
        }
        await upsertProfile({ email, customerId, planCode, isSubscribed });
        break;
      }
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const sub = stripeEvent.data.object;
        const customer = await stripe.customers.retrieve(sub.customer);
        const email = customer?.email || null;
        const planCode = planFromPriceId(sub.items?.data?.[0]?.price?.id);
        const isSubscribed = ACTIVE_STATUSES.has(sub.status);
        await upsertProfile({ email, customerId: sub.customer, planCode, isSubscribed });
        break;
      }
      case "customer.subscription.deleted": {
        const sub = stripeEvent.data.object;
        const customer = await stripe.customers.retrieve(sub.customer);
        const email = customer?.email || null;
        await upsertProfile({
          email,
          customerId: sub.customer,
          planCode: null,
          isSubscribed: false
        });
        break;
      }
      default:
        console.log("\u2139\uFE0F Ignored event:", stripeEvent.type);
    }
  } catch (err) {
    console.error("\u{1F4A5} Handler error:", err);
    return { statusCode: 500, body: "Handler error" };
  }
  return { statusCode: 200, body: "ok" };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
